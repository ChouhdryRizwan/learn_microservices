def my_function()->str:
    return "Hello World"


res = my_function()

print(res)